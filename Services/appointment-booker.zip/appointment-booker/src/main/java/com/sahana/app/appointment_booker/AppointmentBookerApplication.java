package com.sahana.app.appointment_booker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppointmentBookerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppointmentBookerApplication.class, args);
	}

}
