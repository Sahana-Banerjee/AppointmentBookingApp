package com.sahana.app.appointment_booker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentBookerApplicationTests {

	@Test
	void contextLoads() {
	}

}
